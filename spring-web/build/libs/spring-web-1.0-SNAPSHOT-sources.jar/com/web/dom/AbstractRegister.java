package com.web.dom;

import lombok.Data;
import lombok.EqualsAndHashCode;
import jakarta.persistence.*;

@Data
@MappedSuperclass
@EqualsAndHashCode(callSuper = false)
public abstract class AbstractRegister extends ApplicationId {

    @Column(name="username")
    private String userName;

    @Column(name="password")
    private String password;

    @Column(name="inactive")
    private boolean inActive;

    @Column(name="gender")
    private String gender;

    @Column(name="country")
    private String country;

    @Column(name="emailed")
    private String emailId;

    @Column(name="phone_number")
    private String phoneNumber;

    @Column(name="createdate")
    private String createDate;

}
